cd `dirname $0`
 ROOT_PATH=`pwd`
java -Xms256M -Xmx1024M -cp classpath.jar: debug_trunk.bug9595_0_1.Bug9595 --context=Default $* 