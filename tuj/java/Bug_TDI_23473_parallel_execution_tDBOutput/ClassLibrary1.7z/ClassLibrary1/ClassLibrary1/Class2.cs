﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Test1
{
    class Class2
    {
        string s = null;
        public Class2()
        {
            this.s = "Default Constructor Used";
        }

        public string getValue()
        {
            return "Return Value from Class2: " + s;
        }
    }
}
