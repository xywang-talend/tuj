﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Test1
{
    public class Class1
    {
        string s = null;
        public Class1(string s)
        {
            this.s = s;
        }

        public string getValue()
        {
            return "Return Value from Class1: " + s;
        }

    }
}
